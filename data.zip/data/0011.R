# =========================================================================
# 跨模态情绪匹配与 IRI-C(22题版)：数据清洗与 CFA 完整流水线
# =========================================================================

# ---------------------------------------------------------
# Step 0: 加载必要的包
# ---------------------------------------------------------
if (!require("pacman")) install.packages("pacman")
pacman::p_load(tidyverse, psych, lattice, corrplot, lavaan, semPlot, semptools, readr, stringr)

print("--- 开始批量读取和清洗数据 ---")

# ---------------------------------------------------------
# Step 1: 批量读取和整理 IRI 共情量表数据 (22题版)
# ---------------------------------------------------------
iri_files <- list.files(pattern = ".*_IRI_Scale_.*\\.csv")
iri_raw <- map_dfr(iri_files, read_csv, show_col_types = FALSE)

iri_wide <- iri_raw %>%
  select(SubjectID, Item, Score) %>%
  pivot_wider(names_from = Item, values_from = Score) %>%
  mutate(SubjectID = as.numeric(SubjectID)) %>%
  # 【核心修改】：针对 0~4 计分的 2、5、10、11、14 题进行反向计分 (新分数 = 4 - 原分数)
  mutate(
    Q2  = 4 - Q2,
    Q5  = 4 - Q5,
    Q10 = 4 - Q10,
    Q11 = 4 - Q11,
    Q14 = 4 - Q14
  )

print("✅ 22题版 IRI-C 问卷数据读取并反向计分完毕！")

# ---------------------------------------------------------
# Step 2: 批量处理实验数据 (±3SD 和 平均>3s 筛选)
# ---------------------------------------------------------
exp_files <- list.files(pattern = ".*_multimodalemotion_.*\\.csv")
exp_raw <- map_dfr(exp_files, read_csv, show_col_types = FALSE)

# 2.1 提取数值
exp_clean <- exp_raw %>%
  mutate(
    RT = parse_number(as.character(mouse_resp.time)),
    ACC = parse_number(as.character(mouse_resp.corr)),
    clicked_emotion = str_extract(str_to_lower(mouse_resp.clicked_name), "happy|sad|anger|fear|disgust|surprise"),
    trial_type = str_to_lower(trial_type)
  )

# 2.2 剔除个体内的最大最小极端值 (均值 ± 3个标准差)
exp_clean <- exp_clean %>%
  group_by(participant) %>%
  mutate(
    rt_mean = mean(RT, na.rm = TRUE),
    rt_sd = sd(RT, na.rm = TRUE),
    is_outlier = abs(RT - rt_mean) > (3 * rt_sd)
  ) %>%
  filter(!is_outlier) %>% 
  ungroup()

# 2.3 筛选【被试总体平均反应时 > 3秒】的有效被试
valid_participants <- exp_clean %>%
  group_by(participant) %>%
  summarise(overall_mean_RT = mean(RT, na.rm = TRUE)) %>%
  filter(overall_mean_RT > 3.0) %>%  
  pull(participant)

exp_clean <- exp_clean %>%
  filter(participant %in% valid_participants)

print(paste("过滤后，满足平均RT>3秒的有效实验被试数为:", length(valid_participants)))

# 2.4 计算各情绪的均值和无偏击中率 (Wagner's Hu)
exp_summary <- exp_clean %>%
  group_by(participant, trial_type) %>%
  summarise(
    Mean_RT = mean(RT[ACC == 1], na.rm = TRUE), 
    N_actual = n(),
    N_hits = sum(ACC == 1, na.rm = TRUE),
    .groups = "drop"
  )

response_counts <- exp_clean %>%
  group_by(participant, clicked_emotion) %>%
  summarise(N_responses = n(), .groups = "drop") %>%
  rename(trial_type = clicked_emotion) %>%
  filter(!is.na(trial_type))

exp_final <- exp_summary %>%
  left_join(response_counts, by = c("participant", "trial_type")) %>%
  mutate(
    N_responses = replace_na(N_responses, 0),
    Wagner_Hu = ifelse(N_actual > 0 & N_responses > 0, 
                       (N_hits / N_actual) * (N_hits / N_responses), 0)
  ) %>%
  select(participant, trial_type, Mean_RT, Wagner_Hu) %>%
  pivot_wider(
    names_from = trial_type, 
    values_from = c(Mean_RT, Wagner_Hu),
    names_glue = "{trial_type}_{.value}"
  ) %>%
  rename(SubjectID = participant) %>%
  mutate(SubjectID = as.numeric(SubjectID))

print("✅ 实验数据清洗及 Wagner's Hu 计算完毕！")


# ---------------------------------------------------------
# Step 3: 内连接合并数据
# ---------------------------------------------------------
full_data <- inner_join(iri_wide, exp_final, by = "SubjectID")
mydata <- full_data %>% drop_na(Q1) # 确保问卷不为空
write_csv(mydata, "1_Merged_Data.csv")
print(paste("🎉 最终合并成功的配套被试人数为:", nrow(mydata)))


# ---------------------------------------------------------
# Step 4: 异常被试诊断 (Mahalanobis Distance)
# ---------------------------------------------------------
print("--- 开始诊断异常被试 ---")
# 提取 Q1 到 Q22 这 22 道题进行排雷
iri_cols <- mydata %>% select(paste0("Q", 1:22))

d2 <- outlier(iri_cols, plot = FALSE) 
alpha_level <- 0.001
p <- ncol(iri_cols) 
cutoff <- qchisq(1 - alpha_level, df = p)
is_outlier_subj <- d2 > cutoff
num_outliers <- sum(is_outlier_subj, na.rm = TRUE)

cat("Statistical Cutoff (D2):", round(cutoff, 2), "\n")
cat("Number of participants flagged (Mahalanobis):", num_outliers, "\n")

if(num_outliers > 0) {
  worst_indices <- order(d2, decreasing = TRUE)[1:num_outliers]
  clean_means <- colMeans(iri_cols[-worst_indices, ], na.rm = TRUE)
  person_corrs <- apply(iri_cols[worst_indices, ], 1, function(x) {
    cor(as.numeric(x), clean_means, use = "complete.obs")
  })
  results <- data.frame(
    SubjectID = mydata$SubjectID[worst_indices],
    Mahalanobis_D2 = round(d2[worst_indices], 2),
    Person_Rest_Cor = round(person_corrs, 3)
  )
  print("疑似异常被试列表:")
  print(results)
}

clean_data <- mydata[!is_outlier_subj, ]
cat("排雷后，准备进入 CFA 的最终被试数:", nrow(clean_data), "\n")


# ---------------------------------------------------------
# Step 5: IRI-C (22题版) CFA 建模与可视化
# ---------------------------------------------------------
print("--- 22题版 IRI-C 验证性因子分析 (CFA) ---")

# 【核心修改】：完全按照你提供的 22题版 结构写模型！
model_iri <- ' 
  PT =~ Q6 + Q9 + Q15 + Q19 + Q22
  FS =~ Q3 + Q5 + Q10 + Q12 + Q17 + Q20
  EC =~ Q1 + Q2 + Q7 + Q11 + Q14 + Q16
  PD =~ Q4 + Q8 + Q13 + Q18 + Q21
'

# 使用 MLR 稳健估计拟合模型
fit_iri <- cfa(model_iri, data = clean_data, estimator = "MLR")

# 输出 CFA 结果
summary(fit_iri, fit.measures = TRUE, standardized = TRUE)

# 使用 semPlot 绘制路径图
p_plot <- semPaths(fit_iri, 
                   style="lisrel", 
                   residuals = FALSE,
                   what = "std",           
                   whatLabels = "std", 
                   minimum = 0.2,          
                   edge.label.cex = 0.6, 
                   layout ='tree2',
                   edge.label.color = "black", 
                   rotation = 2, 
                   label.scale = FALSE, 
                   label.cex = 0.7,
                   equalizeManifests = FALSE, 
                   optimizeLatRes = TRUE, 
                   node.width = 1.0, 
                   edge.width = 0.5, 
                   shapeMan = "rectangle", 
                   shapeLat = "ellipse", 
                   shapeInt = "triangle", 
                   sizeMan = 3.5, 
                   sizeInt = 2, 
                   sizeLat = 5, 
                   curve=2, 
                   unCol = "#070b8c")

plot(p_plot)
print("✅ 全部运行完毕！")

# 查看修正指数 (Modification Indices)
print(modindices(fit_iri, sort = TRUE, maximum.number = 20))

model_iri_revised <- ' 
  PT =~ Q6 + Q9 + Q15 + Q19 + Q22
  FS =~ Q3 + Q5 + Q10 + Q12 + Q17 + Q20
  EC =~ Q1 + Q2 + Q7 + Q11 + Q14 + Q16
  PD =~ Q4 + Q8 + Q13 + Q18 + Q21
  
  # 允许语义重叠的题项残差相关
  Q5 ~~ Q10
  Q2 ~~ Q14
'
# 重新拟合
fit_iri_revised <- cfa(model_iri_revised, data = clean_data, estimator = "MLR")
summary(fit_iri_revised, fit.measures = TRUE, standardized = TRUE)






# 提取 4 个维度的标准化因子得分，并合并回 clean_data
factor_scores <- lavPredict(fit_iri, method = "Bartlett") # Bartlett 方法提取出的得分更稳健
clean_data <- cbind(clean_data, factor_scores)

# 现在你的 clean_data 中多了 PT, FS, EC, PD 四列数据，这就是你的“共情特质”指标！
library(lme4)
library(lmerTest)

# 转换数据为长表格式，以便进行混合模型分析
long_data <- clean_data %>%
  pivot_longer(cols = ends_with("Wagner_Hu"), 
               names_to = "emotion", 
               values_to = "hu_score") %>%
  mutate(emotion = str_remove(emotion, "_Wagner_Hu"))

# 运行核心模型：
# 预测 Hu 分数是否受到 共情能力(EC) 和 情绪类型(emotion) 的影响
model_final <- lmer(hu_score ~ EC * emotion + (1 | SubjectID), data = long_data)

summary(model_final)


# =========================================================================
# 终极版：自动化多模型分析流水线
# =========================================================================

library(lme4)
library(lmerTest)

# 1. 准备长表数据 (确保你的 clean_data 已经包含了刚才提取的因子得分)
# 假设 clean_data 已经包含了 PT, FS, EC, PD 四列因子得分
long_data <- clean_data %>%
  pivot_longer(cols = ends_with("_Wagner_Hu"), 
               names_to = "emotion", 
               values_to = "hu_score") %>%
  mutate(emotion = str_remove(emotion, "_Wagner_Hu"))

# 2. 定义我们要跑的 4 个共情维度
empathy_dimensions <- c("PT", "FS", "EC", "PD")

# 3. 循环跑 4 个混合模型并输出结果
results_list <- list()

for (dim in empathy_dimensions) {
  cat("\n======================================================\n")
  cat("正在分析共情维度:", dim, "\n")
  cat("======================================================\n")
  
  # 构建公式：hu_score ~ 维度 * 情绪 + (1|被试)
  formula_str <- paste0("hu_score ~ ", dim, " * emotion + (1 | SubjectID)")
  model <- lmer(as.formula(formula_str), data = long_data)
  
  # 打印摘要
  print(summary(model))
  
  # 保存模型方便后续查看
  results_list[[dim]] <- model
}

# 提示：如果某个维度的交互项 (例如 PT:emotionhappy) 的 Pr(>|t|) < 0.05，
# 说明那个维度显著调节了对该情绪的识别。





# =========================================================================
# Cross-modal Emotion Matching and IRI-C (22-item) Pipeline
# =========================================================================

# ---------------------------------------------------------
# Step 0: Load required packages
# ---------------------------------------------------------
if (!require("pacman")) install.packages("pacman")
pacman::p_load(tidyverse, psych, lattice, corrplot, lavaan, semPlot, semptools, readr, stringr, gridExtra)

print("--- Starting data processing pipeline ---")

# ---------------------------------------------------------
# Step 1: Process IRI-C (22-item version)
# ---------------------------------------------------------
iri_files <- list.files(pattern = ".*_IRI_Scale_.*\\.csv")
iri_raw <- map_dfr(iri_files, read_csv, show_col_types = FALSE)

iri_wide <- iri_raw %>%
  select(SubjectID, Item, Score) %>%
  pivot_wider(names_from = Item, values_from = Score) %>%
  mutate(SubjectID = as.numeric(SubjectID)) %>%
  # Reverse scoring: NewScore = 4 - OriginalScore
  mutate(
    Q2  = 4 - Q2,
    Q5  = 4 - Q5,
    Q10 = 4 - Q10,
    Q11 = 4 - Q11,
    Q14 = 4 - Q14
  )

print("✅ IRI-C data processed and reverse-scored.")

# ---------------------------------------------------------
# Step 2: Process experimental data (Exclude outliers and filter subjects)
# ---------------------------------------------------------
exp_files <- list.files(pattern = ".*_multimodalemotion_.*\\.csv")
exp_raw <- map_dfr(exp_files, read_csv, show_col_types = FALSE)

exp_clean <- exp_raw %>%
  mutate(
    RT = parse_number(as.character(mouse_resp.time)),
    ACC = parse_number(as.character(mouse_resp.corr)),
    clicked_emotion = str_extract(str_to_lower(mouse_resp.clicked_name), "happy|sad|anger|fear|disgust|surprise"),
    trial_type = str_to_lower(trial_type)
  )

# Exclude ±3SD outliers per participant
exp_clean <- exp_clean %>%
  group_by(participant) %>%
  mutate(
    rt_mean = mean(RT, na.rm = TRUE),
    rt_sd = sd(RT, na.rm = TRUE),
    is_outlier = abs(RT - rt_mean) > (3 * rt_sd)
  ) %>%
  filter(!is_outlier) %>% 
  ungroup()

# Filter subjects with mean RT > 3 seconds
valid_participants <- exp_clean %>%
  group_by(participant) %>%
  summarise(overall_mean_RT = mean(RT, na.rm = TRUE)) %>%
  filter(overall_mean_RT > 3.0) %>%  
  pull(participant)

exp_clean <- exp_clean %>%
  filter(participant %in% valid_participants)

print(paste("Valid participants (Mean RT > 3s):", length(valid_participants)))

# Calculate Hu (Wagner's Unbiased Hit Rate)
exp_summary <- exp_clean %>%
  group_by(participant, trial_type) %>%
  summarise(
    Mean_RT = mean(RT[ACC == 1], na.rm = TRUE),
    N_actual = n(),
    N_hits = sum(ACC == 1, na.rm = TRUE),
    .groups = "drop"
  )

response_counts <- exp_clean %>%
  group_by(participant, clicked_emotion) %>%
  summarise(N_responses = n(), .groups = "drop") %>%
  rename(trial_type = clicked_emotion) %>%
  filter(!is.na(trial_type))

exp_final <- exp_summary %>%
  left_join(response_counts, by = c("participant", "trial_type")) %>%
  mutate(
    N_responses = replace_na(N_responses, 0),
    Wagner_Hu = ifelse(N_actual > 0 & N_responses > 0, (N_hits / N_actual) * (N_hits / N_responses), 0)
  ) %>%
  select(participant, trial_type, Mean_RT, Wagner_Hu) %>%
  pivot_wider(
    names_from = trial_type, 
    values_from = c(Mean_RT, Wagner_Hu),
    names_glue = "{trial_type}_{.value}"
  ) %>%
  rename(SubjectID = participant) %>%
  mutate(SubjectID = as.numeric(SubjectID))

# ---------------------------------------------------------
# Step 3: Merge and Diagnose Outliers
# ---------------------------------------------------------
full_data <- inner_join(iri_wide, exp_final, by = "SubjectID")
mydata <- full_data %>% drop_na(Q1)
clean_data <- mydata 

# Mahalanobis Distance for subject diagnostic
iri_cols <- clean_data %>% select(paste0("Q", 1:22))
d2 <- outlier(iri_cols, plot = FALSE) 
cutoff <- qchisq(1 - 0.001, df = ncol(iri_cols))
clean_data <- clean_data[d2 <= cutoff, ]

print(paste("Final valid N for analysis:", nrow(clean_data)))

# ---------------------------------------------------------
# Step 4: CFA and Visualization
# ---------------------------------------------------------
model_iri <- ' 
  PT =~ Q6 + Q9 + Q15 + Q19 + Q22
  FS =~ Q3 + Q5 + Q10 + Q12 + Q17 + Q20
  EC =~ Q1 + Q2 + Q7 + Q11 + Q14 + Q16
  PD =~ Q4 + Q8 + Q13 + Q18 + Q21
  Q5 ~~ Q10
  Q2 ~~ Q14
'

fit_iri <- cfa(model_iri, data = clean_data, estimator = "MLR")
summary(fit_iri, fit.measures = TRUE, standardized = TRUE)

# Visualize path diagram
plot(semPaths(fit_iri, style="lisrel", what="std", whatLabels="std", layout="tree2", residuals=FALSE))

# ---------------------------------------------------------
# Step 5: Automated Visualization (ggplot2)
# ---------------------------------------------------------
long_data <- clean_data %>%
  pivot_longer(cols = ends_with("_Wagner_Hu"), 
               names_to = "emotion", 
               values_to = "hu_score") %>%
  mutate(emotion = str_remove(emotion, "_Wagner_Hu"))

# Plot trends
ggplot(long_data, aes(x = PT, y = hu_score, color = emotion)) +
  geom_smooth(method = "lm", se = FALSE) + 
  theme_minimal() +
  labs(title = "Trends of Emotion Recognition (Hu) by PT Factor", x = "PT Score", y = "Hu Score")







# 1. 确保数据已经是长表格式 (long_data)
# 确保你的 R 环境里已经运行过之前的合并与处理步骤
library(ggplot2)
library(gridExtra)

# 2. 定义绘图函数：PT, FS, EC, PD 四个维度一网打尽
plot_empathy_emotion <- function(dimension) {
  ggplot(long_data, aes(x = .data[[dimension]], y = hu_score, color = emotion)) +
    geom_smooth(method = "lm", se = FALSE, size = 0.8) +
    geom_point(alpha = 0.2, size = 0.5) +  # 加入散点增加可信度
    theme_minimal() +
    labs(title = paste("Effect of", dimension, "on Hu Score"),
         x = paste(dimension, "Factor Score"), 
         y = "Wagner's Hu") +
    theme(legend.position = "right")
}

# 3. 生成四张图
p_pt <- plot_empathy_emotion("PT")
p_fs <- plot_empathy_emotion("FS")
p_ec <- plot_empathy_emotion("EC")
p_pd <- plot_empathy_emotion("PD")

# 4. 拼图：将四张图合并为一个 2x2 的大图
grid.arrange(p_pt, p_fs, p_ec, p_pd, ncol = 2, nrow = 2)



